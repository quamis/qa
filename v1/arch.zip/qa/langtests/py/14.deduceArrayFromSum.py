import sys
import helpers
import hashlib, zlib
import re
import copy

def deduceArrayFromSum(arr, asum, offset, maxOffset, li, mi, xor, lxor):
    if offset==maxOffset and asum:
        return 1
                
    if offset<maxOffset and asum:
        if asum>0:
            i = min(li, asum)
            while i>=mi:
                ns = asum-i
                arr[offset] = i
                cxor = lxor ^ i
                
                if ns==0:
                    if xor==cxor:
                        cb(arr, cxor, xor)
                    else:
                        return 0
                else:
                    ret = deduceArrayFromSum(arr, ns, offset+1, maxOffset, i, mi, xor, cxor)
                    if ret>0:
                        return ret-1
                i=i-1
    return 0

def cb(data, cxor, xor):
    global crc32
    
    datacrc = zlib.crc32(str(data)) & 0xffffffff
    
    #helpers.dlog(">%s[%d]\r" % (re.sub("[^a-zA-Z0-9]", "_", data), len(data)))

    if datacrc==crc32:
        helpers.dlog("Found data\n")
        helpers.dlog("Data: '%s'[%d]\n" % (data, len(data)))
        sys.exit()
        

asum = int(sys.argv[1])
alen = int(sys.argv[2])
md5 = str(sys.argv[3])
crc32 = int(str(sys.argv[4]), 16) & 0xffffffff
xor = int(str(sys.argv[6]), 16) & 0xff


sarr = "\x00" * (alen)
arr = bytearray(sarr)
helpers.dlog("Started deduce array from sum\n")
deduceArrayFromSum(arr, asum, 0, alen, 0xff, 0x00, xor, 0x00)
helpers.dlog("Cannot decode input data\n")

