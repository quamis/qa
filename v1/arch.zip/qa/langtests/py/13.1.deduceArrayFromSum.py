import sys
import helpers
import hashlib, zlib
import re
import copy
from itertools import combinations

def deduceArrayFromSum(tgt, len_):
    yield tuple([tgt]+[0]*(len_-1))
    for t in combinations(range(tgt+1), len_):
        if sum(t)==tgt:
            yield t[::-1]


def cb(data):
    global crc32
    
    datacrc = zlib.crc32(data) & 0xffffffff
    
    #helpers.dlog(">%s[%d]\r" % (re.sub("[^a-zA-Z0-9]", "_", data), len(data)))
    
    if datacrc==crc32:
        helpers.dlog("Found data\n")
        helpers.dlog("Data: '%s'[%d]\n" % (data, len(data)))
        sys.exit()
        

asum = int(sys.argv[1]);
alen = int(sys.argv[2]);
md5 = str(sys.argv[3]);
crc32 = int(str(sys.argv[4]), 16) & 0xffffffff;

sarr = "\x00" * (alen)
arr = bytearray(sarr)

helpers.dlog("Started deduce array from sum\n")
#deduceArrayFromSum(alen, asum)
#print deduceArrayFromSum(asum, alen)
for arr in deduceArrayFromSum(asum, alen):
    print arr
    exit()
helpers.dlog("Cannot decode input data\n")
