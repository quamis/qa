import sys
import helpers
import hashlib
import re
import copy

def deduceArrayFromSum(arr, asum, offset, maxOffset, li, mi):
    if offset<=maxOffset:
        if asum>0:
            i = min(li, asum)
            while i>=mi:
                if asum>=i and offset<maxOffset:
                    #arr = arr[0:offset]+chr(i)+arr[offset]
                    arr = arr[:offset] + chr(i) + arr[offset+1:]
                    deduceArrayFromSum(arr, asum-i, offset+1, maxOffset, i, mi)
                i=i-1
        elif asum==0:
            cb(arr)

def cb(data):
    global md5
    
    datamd5 = hashlib.md5(data).hexdigest()
    
    #helpers.dlog("%s[%d] %s\r" % (re.sub("[^a-zA-Z0-9]", "_", data), len(data), datamd5))
    
    if datamd5==md5:
        helpers.dlog("Found data\n")
        helpers.dlog("Data: '%s'[%d]\n" % (data, len(data)))
        sys.exit()
        

asum = int(sys.argv[1]);
alen = int(sys.argv[2]);
md5 = str(sys.argv[3]);

arr = "\x00" * (alen)
helpers.dlog("Started deduce array from sum\n")
deduceArrayFromSum(arr, asum, 0, alen, 0xff, 0x00)
helpers.dlog("Cannot decode input data\n")

