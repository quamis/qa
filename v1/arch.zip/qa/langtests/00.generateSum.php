<?php
$data = "123456";

$len = strlen($data);

$arri = Array();
$arrc = Array();
$xor = 0;
for($i=0; $i<$len; $i++) {
	$arri[] = ord($data[$i]);
	$arrc[] = $data[$i];
	$xor = ($xor ^ ord($data[$i])) & 0xff;
}

rsort($arrc);
printf("Sum of data '%s': :%d, len: %d, md5: %s, crc32: %s, adler32: %s, xor: 0x%02x\n", implode("", $arrc), array_sum($arri), count($arri), 
	md5(implode("", $arrc)), 
	bin2hex(mhash(MHASH_CRC32B, implode("", $arrc))),
	bin2hex(mhash(MHASH_ADLER32, implode("", $arrc))),
	$xor
);
