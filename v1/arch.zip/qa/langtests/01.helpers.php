<?php
$CACHE = Array();

function dlog($str) {
	global $CACHE;
	$tm = microtime(true);
	if(!$CACHE[__FUNCTION__]['time']) {
		$CACHE[__FUNCTION__]['time'] = $tm;
	}

	printf("[%6.3f] %s", $tm - $CACHE[__FUNCTION__]['time'], $str);
	flush();
}

function reimplode($arri) {
    $arrc = Array();
    foreach($arri as $v) {
        $arrc[] = chr($v);
    }

    return implode("", $arrc);
}
