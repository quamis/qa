Tot procesul de decompresie este impartit in 2 pasi complet separati, dar secventiali:
 - generarea listei initiale, plecand de la suma caracterelor. Este denumita deduceArrayFromSum()
 - generarea tuturor permutarilor posibile plecand de la rezultatul rezultat mai sus. Este denumita pc_permute()
 
 Fiecare pas poate primi diverse hint-uri, cu conditia ca respectivele hint-uri sa nu necesite mai mult spatiu decat economisesc.
 
 deduceArrayFromSum
    - genereaza un array de caractere a caror suma da la fel cu datelor initiale
    - poate primi o lista de intervale cu "sub-sume" precalculate, astfel incat la final sa nu fie nevoie sa calculeze toate combinatiile 
        posible pt un array de 1000 elemente, ci doar pt unul de $window elemente.
        - pentru fiecare interval poate primi mai departe un interval numeric, care reprezinta intervalul de caractere ASCII in care ar 
            trebui sa incerce "deduce" sa deduca o suma. Acest hint are sens cand dictionarul(descris mai jos) nu aduce destule economii 
            cat sa se merite utilizarea sa
        - pentru fiecare interval poate primi un "dictionar" cu caracterele folosite in acel interval. Acest hint are sens cand numarul de 
            elemente din dictionar este f mic, astfel incat sa se faca totusi economii.
            
            

pc_permute
    - se separa intervalul de intrare in bucati de cate $window bytes latime, si se caluleaza crc32 pt fiecare subinterval
        acest crc32 este folosit pe masura ce se genereaza permutari, pt a pre-valida daca segmentul generat este corect, iar daca nu este corect, 
        se poate opri tot lantul de permutari pt acel caracter(de face un return recursiv din functie, astfel incat sa nu se mai ncerce variante 
        despre care se stie sigur ca nu sunt utilizabile
    
    
 

