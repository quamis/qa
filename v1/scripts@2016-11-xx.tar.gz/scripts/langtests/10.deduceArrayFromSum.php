<?php
# took 928s for "mere"

require_once("01.helpers.php");

function deduceArrayFromSum($arr, $sum, $offset, $maxOffset, $li, $mi) {
	if($offset<=$maxOffset){
		if ($sum>0) {
			for($i=min($li, $sum); $i>=$mi; $i--) {
				if ($sum>=$i && $offset<$maxOffset) {
					$arr[$offset] = $i;
					deduceArrayFromSum($arr, $sum-$i, $offset+1, $maxOffset, $i, $mi);
				}
			}
		}
		elseif ($sum==0) {
			cb($arr);
		}
	}
}

function cb($arr) {
	$data = reimplode($arr);
	#printf("Data: %s\n", $data);
	
	
	global $md5;
	if(md5($data)==$md5) {
		dlog(sprintf("\n\n Found data:\n", $data));
		dlog(sprintf("Data: %s\n", $data));
		exit();
	}
}

$sum = (int)$argv[1];
$len = (int)$argv[2];
$md5 = (string)$argv[3];

$arr = array_fill(0, $len, 0);

dlog(sprintf("Started deduce array from sum\n"));
deduceArrayFromSum($arr, $sum, 0, $len, 0xff, 0x00);
dlog(sprintf("Cannot decode input data\n"));

printf("\n\n");
throw new Exception("Cannot decode input data");