<?php
$data = "Lorem Ipsum is simply dummy text";

$len = strlen($data);

$arri = Array();
$arrc = Array();
$xor = 0;
$rxor = 0;
for($i=0; $i<$len; $i++) {
	$arri[] = ord($data[$i]);
	$arrc[] = $data[$i];
	$xor = ($xor ^ ord($data[$i])) & 0xff;
	$rxor = ($rxor << 1) ^ ord($data[$i]);
}

rsort($arrc);
rsort($arri);

$b0map = 0x00;
for($i=0; $i<$len; $i++) {
	echo ($arri[$i] & 0x01)."\n";
	$b0map = $b0map | (($arri[$i] & 0x01) << $i);
}
#printf("Sum of data '%s': :%d, len: %d, md5: %s, crc32: %s, adler32: %s, xor: 0x%02x\n", implode("", $arrc), array_sum($arri), count($arri), 
printf("%s/%s: %d %d %s %s %s 0x%02x 0x%08x 0x%08x\n",
	$data, 
	implode("", $arrc), 
	array_sum($arri), 
	count($arri),
	md5(implode("", $arrc)), 
	bin2hex(mhash(MHASH_CRC32B, implode("", $arrc))),
	bin2hex(mhash(MHASH_ADLER32, implode("", $arrc))),
	$xor,
	$rxor,
	$b0map
);
