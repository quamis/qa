import sys, time
import hashlib, zlib
import helpers

# 26s pt cel de 16 ch

class qacompress(object):
    def __init__(self, fin, fout):
        self.fin = fin
        self.fout = fout
        self.counters = {}
        self.md5 = 0x00
        self.crc32 = 0x00
        self.data_len = 0
        
    def _compress_block(self, data):
        print data
    
    def stream_compress(self):
        print self.fin
        f = open(self.fin)
        while True:
            data = bytearray(f.read(16))
            if not data:
                break
            self._compress_block(data)

if __name__ == '__main__':
    qac = qacompress(sys.argv[1], sys.argv[2])
    qac.stream_compress()
