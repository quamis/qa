import datetime
import sys

def microtime():
    dt = datetime.datetime.now()
    unixtime = dt - datetime.datetime(1970, 1, 1)
    return unixtime.days*24*60*60 + unixtime.seconds + unixtime.microseconds/1000000.0

dlog_time = microtime()
dlog_ltime = dlog_time

def dlog(text):
    global dlog_time    # Needed to modify global copy of globvar
    dt = microtime()
    sys.stdout.write("[%6.3f] %s" % (dt - dlog_time, text))
    #dlog_time = dt
    sys.stdout.flush()
    
def dlogt(minTime, text):
    global dlog_time    # Needed to modify global copy of globvar
    global dlog_ltime
    dt = microtime()
    if(dt-dlog_ltime>minTime):
        sys.stdout.write("[%6.3f] %s" % (dt - dlog_time, text))
        dlog_ltime = dt
        sys.stdout.flush()
    

def reimplode(iarr):
    hexdata = ''.join([chr(item) for item in iarr])
    return hexdata
    
def reimplodehex(iarr):
    hexdata = ''.join([("%02x" % item) for item in iarr])
    return hexdata


counter = {
    'hits': 0,
    'loops':0,
}

"""
$CACHE = Array();

function dlog($str) {
	global $CACHE;
	$tm = microtime(true);
	if(!$CACHE[__FUNCTION__]['time']) {
		$CACHE[__FUNCTION__]['time'] = $tm;
	}

	printf("[%6.3f] %s", $tm - $CACHE[__FUNCTION__]['time'], $str);
	flush();
}
"""
