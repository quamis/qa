import sys
import helpers
import hashlib, zlib
import re
import copy

def iter_fun(sum, deepness, myString, Total):
    if deepness == 0:
        if sum == Total:
            print myString
    else:    
        for i in xrange(min(10, Total - sum + 1)):
            iter_fun(sum + i,deepness - 1,myString + chr(i),Total) 

def deduceArrayFromSum(digits, Tot):
    iter_fun(0,digits,"",Tot) 


def cb(data):
    global crc32
    
    datacrc = zlib.crc32(data) & 0xffffffff
    
    #helpers.dlog(">%s[%d]\r" % (re.sub("[^a-zA-Z0-9]", "_", data), len(data)))
    
    if datacrc==crc32:
        helpers.dlog("Found data\n")
        helpers.dlog("Data: '%s'[%d]\n" % (data, len(data)))
        sys.exit()
        

asum = int(sys.argv[1]);
alen = int(sys.argv[2]);
md5 = str(sys.argv[3]);
crc32 = int(str(sys.argv[4]), 16) & 0xffffffff;

sarr = "\x00" * (alen)
arr = bytearray(sarr)

helpers.dlog("Started deduce array from sum\n")
#deduceArrayFromSum(alen, asum)
deduceArrayFromSum(alen, asum)
helpers.dlog("Cannot decode input data\n")
