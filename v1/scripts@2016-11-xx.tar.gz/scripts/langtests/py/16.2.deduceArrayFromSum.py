import sys, time
import hashlib, zlib
import helpers
import random

import multiprocessing
from multiprocessing import Pool

# 26s pt cel de 16 ch

class deduceArrayFromSum(object):
	def __init__(self, data_sum, data_len):
		self.expected_sum = data_sum
		self.data_len = data_len
		self.startupData = None
		self.interval = ()
		self.dictionary = {}
		self.dictionary_interval = ()

		self.expected_xor = None
		self.expected_b0map = None
		self.expected_crc32 = None
		self.expected_md5 = None

		self.response = None
		self.counters = {'hits_sum': 0, 'hits_b0map':0, 'hits_xor': 0, 'hits_crc32': 0, 'hits_md5': 0}

	def expect_xor(self, val):
		self.expected_xor = val
	
	def expect_b0map(self, val):
		self.expected_b0map = val

	def expect_crc32(self, val):
		self.expected_crc32 = val

	def expect_md5(self, val):
		self.expected_md5 = val

	def hint_interval(self, interval_start, interval_end):
		intv = (interval_start, interval_end)
		self.interval = (max(intv), min(intv))

	def hint_dictionary(self, dictionary):
		d = list(set(dictionary)) # keep only unique values
		d.sort(reverse=True)
		self.dictionary_interval = (min(d), max(d))
		self.dictionary = d

	def runFromStartupData(self, startup_data_lst):
		startup_data = "".join(map(chr, list(startup_data_lst)))
		self.startupData = startup_data

		data = bytearray("\x00" * (self.data_len))
		data = bytearray(startup_data) + data[len(startup_data):]

		expected_sum = self.expected_sum - sum(startup_data_lst)
		lxor = 0x00
		for i in startup_data_lst:
			lxor = lxor^i
			
		lb0map = 0x00
		idx = 0
		for i in startup_data_lst:
			lb0map = lb0map | ((i & 0x01)<<idx)
			idx+=1

		lastval = startup_data_lst[-1]

		#print("sdata: '%s'(s:%d), exps: %d, s.exps: %d" % (startup_data, sum(map(ord, list(startup_data))), expected_sum, self.expected_sum))
		#helpers.dlog("  lb0map: %s\n" % ("{0:016b}".format(lb0map)))
		#exit()

		if len(self.dictionary):
			helpers.dlog("Using dictionary of %d elements, startup: %s[%d]\n" % (len(self.dictionary), startup_data, len(startup_data)))
			self._runOnDictionary(data, expected_sum, len(startup_data), lxor, lb0map, self.dictionary.index(lastval))
		elif len(self.interval):
			helpers.dlog("Using interval of %d elements, startup: %s[%d]\n" % (self.interval[0] - self.interval[1], startup_data, len(startup_data)))
			self._runOnInterval(data, expected_sum, len(startup_data), lxor, lb0map, lastval)
		else:
			#helpers.dlog("Using brute-force, startup: %s[%d]\n" %(startup_data, len(startup_data)))
			helpers.dlog("Using brute-force, startup: 0x%s[%d]\n" %(''.join(format(ord(x), '02x') for x in startup_data), len(startup_data)))
			self.interval = (0xff, 0x00)
			self._runOnInterval(data, expected_sum, len(startup_data), lxor, lb0map, lastval)
			self.interval = ()
		return self.response

	def run(self):
		data = bytearray("\x00" * (self.data_len))

		if len(self.dictionary):
			helpers.dlog("Using dictionary of %d elements\n" % (len(self.dictionary)))
			self._runOnDictionary(data, self.expected_sum, 0, 0x00, 0x00, 0)
		elif len(self.interval):
			helpers.dlog("Using interval of %d elements\n" % (self.interval[0] - self.interval[1]))
			self._runOnInterval(data, self.expected_sum, 0, 0x00, 0x00, self.interval[0])
		else:
			helpers.dlog("Using brute-force\n")
			self.interval = (0xff, 0x00)
			self._runOnInterval(data, self.expected_sum, 0, 0x00, 0x00, self.interval[0])
			self.interval = ()
		return self.response


	def _runOnDictionary(self, data, csum, d, lxor, lb0map, dictionaryStartOffset):
		if d==self.data_len and csum:
			return 0

		if d<self.data_len and csum:
			offset = dictionaryStartOffset
			internalOffset=0

			for i in self.dictionary[offset+internalOffset:]:
				nsum = csum-i
				data[d] = i
				cxor = lxor ^ i

				if nsum==0: # hit target sum
					self.counters['hits_sum']+=1
					#helpers.dlog("Found sum match on %s\n" % (data))

					if self.expected_xor==cxor:
						self.counters['hits_xor']+=1
						#helpers.dlog("Found xor match\n")
						if self.checkSuccess(data):
							return d    # exit from all current function calls
					else:
						if self.counters['hits_sum']%1000==0:
							self.progress(data) # optimize this out
						return 0

				elif nsum<0:
					return 0
				elif nsum<self.dictionary_interval[0]:
					return 0
				else:
					ret = self._runOnDictionary(data, nsum, d+1, cxor, offset+internalOffset)
					if ret>0:
						return ret-1

				internalOffset+=1
		return 0

	def _runOnInterval(self, data, csum, d, lxor, lb0map, intervalStart):
		if d==self.data_len and csum:
			return 1
			
		if d<self.data_len and csum:
			i = min(intervalStart, csum)

			lb0map_orig = lb0map
			while i>=self.interval[1]:
				ex_b0map_i = (self.expected_b0map & (0x01<<d)) >> d
				b0map_i = (i & 0x01)
				
				if ex_b0map_i==b0map_i:
					nsum = csum-i # new sum, hopefully as close to 0 as possible
					data[d] = i
					cxor = lxor ^ i
					lb0map = lb0map_orig | ( b0map_i << d)
					if nsum==0: # hit target sum
						self.counters['hits_sum']+=1
						#helpers.dlog("Found sum match\n")
						
						if self.expected_b0map==lb0map:
							self.counters['hits_b0map']+=1
							if self.expected_xor==cxor:
								self.counters['hits_xor']+=1
								#helpers.dlog("Found xor match\n")
								if self.checkSuccess(data):
									helpers.dlog("  lb0map: %s\n" % ("{0:016b}".format(lb0map)))
									helpers.dlog("s.lb0map: %s\n" % ("{0:016b}".format(self.expected_b0map)))
									return d    # exit from all current function calls
							else:
								if self.counters['hits_sum']%10000==0:
									self.progress(data) # optimize this out
								return 0
					elif nsum<0:
						return 0
					elif nsum<self.interval[1]:
						return 0
					else:
						ret = self._runOnInterval(data, nsum, d+1, cxor, lb0map, i)
						if ret>0:
							return ret-1
				i=i-1
		return 0

	def createStartupIntervals(self):
		if len(self.dictionary):
			intvs = len(self.dictionary)
			if intvs>20:
				d_max = 2
			elif intvs>12:
				d_max = 3
			elif intvs>4:
				d_max = 4
			else:
				d_max = 2
			
			l = self._createStartupIntervalsOnDictionary(0, d_max, bytearray("\x00" * d_max), self.dictionary, [])
		elif len(self.interval):
			intvs = self.interval[0] - self.interval[1]
			if intvs>20:
				d_max = 2
			elif intvs>12:
				d_max = 3
			elif intvs>4:
				d_max = 4
			else:
				d_max = 2
			l = self._createStartupIntervalsOnInterval(0, d_max, bytearray("\x00" * d_max), [])
		else:
			d_max = 2
			self.interval = (0xff, 0x00)
			l = self._createStartupIntervalsOnInterval(0, d_max, bytearray("\x00" * d_max), [])
			self.interval = ()

		return l

	def _createStartupIntervalsOnDictionary(self, d, d_max, data, dictionary, lst):
		if d==d_max:
			lst.append(data[:])  # append a clone of the data
			return lst

		idx = 0
		for i in dictionary:
			data[d] = i
			lst = self._createStartupIntervalsOnDictionary(d+1, d_max, data, dictionary[idx:], lst)
			idx+=1

		return lst


	def _createStartupIntervalsOnInterval(self, d, d_max, data, lst):
		if d==d_max:
			lst.append(data[:])  # append a clone of the data
			return lst

		i = self.interval[0]
		while i>=self.interval[1]:
			data[d] = i
			lst = self._createStartupIntervalsOnInterval(d+1, d_max, data, lst)
			i=i-1

		return lst

	def progress(self, data):
		"""
		helpers.dlogt(0.2, "%s, %s/%s/%d/%d\r" % (re.sub("[^a-zA-Z0-9]", "_", data),
			(str(self.counters['hits_sum']) if self.counters['hits_sum']<10000 else str(self.counters['hits_sum']/1000)+"k"),
			(str(self.counters['hits_xor']) if self.counters['hits_xor']<10000 else str(self.counters['hits_xor']/1000)+"k"),
			self.counters['hits_crc32'],
			self.counters['hits_md5'])
		)
		"""
		pass

	def checkSuccess(self, data):
		datacrc = zlib.crc32(str(data)) & 0xffffffff
		if datacrc==self.expected_crc32:
			self.counters['hits_crc32']+=1
			datamd5 = hashlib.md5(data).hexdigest()
			if datamd5==self.expected_md5:
				self.counters['hits_md5']+=1
				helpers.dlog("\n\nFound md5 match\n")
				helpers.dlog("Data: '%s'[%d]\n" % (data, len(data)))
				self.response = data
				return True

		return False

def process_main(asum, alen, md5, crc32, xor, b0map, startup_data, dictionary, interval):
	d = deduceArrayFromSum(asum, alen)
	if len(dictionary):
		d.hint_dictionary(dictionary)
	if len(interval):
		d.hint_interval(interval[0], interval[1])
	d.expect_xor(xor)
	d.expect_b0map(b0map)
	d.expect_crc32(crc32)
	d.expect_md5(md5)
	return (d.runFromStartupData(startup_data), d.counters, d.startupData)


result_list = []
counters_list = []
def process_end_callback(result):
	global result_list
	global counters_list
	if result[0]:
		result_list.append(result[0])

	if result[1]:
		counters_list.append(result[1])
		#print "%s : %s" % (result[2], result[1])

	#print "-----------------------"
	#print counters_list

if __name__ == '__main__':
	asum = int(sys.argv[1])
	alen = int(sys.argv[2])
	md5 = str(sys.argv[3])
	crc32 = int(str(sys.argv[4]), 16) & 0xffffffff
	xor = int(str(sys.argv[6]), 16) & 0xff
	b0map = int(str(sys.argv[8]), 16) & 0xffff


	helpers.dlog("Started deduce array from sum\n")
	#dictionary = map(ord, list("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "))
	dictionary = {}
	#interval = (ord('a'), ord('y'))
	interval = ()

	d = deduceArrayFromSum(asum, alen)
	if len(dictionary):
		d.hint_dictionary(dictionary)
	if len(interval):
		d.hint_interval(interval[0], interval[1])

	helpers.dlog("createStartupIntervals\n")
	intv = d.createStartupIntervals()
	helpers.dlog("    ...done\n")
	#exit()

	d.expect_xor(xor)
	d.expect_crc32(crc32)
	d.expect_md5(md5)


	use_mp = False

	if use_mp:
		pool = Pool(processes=multiprocessing.cpu_count())

		for i in intv:
			pool.apply_async(process_main, [asum, alen, md5, crc32, xor, b0map, i, dictionary, interval], callback=process_end_callback)    # evaluate "f(10)" asynchronously
		pool.close()


		while 1:
			if len(result_list):
				print("Result: %s" % (result_list))
				pool.terminate()
				break
			time.sleep(3)
			if len(multiprocessing.active_children())==0:
				break

		pool.join()
	else:
		for i in intv:
			process_end_callback(process_main(asum, alen, md5, crc32, xor, b0map, i, dictionary, interval))
			if len(result_list):
				print("Result: %s" % (result_list))
				break

	print("Result: %s" % (result_list))


