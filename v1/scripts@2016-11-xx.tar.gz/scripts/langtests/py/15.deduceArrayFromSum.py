import sys
import hashlib, zlib
import re
import helpers

from multiprocessing import Process, Queue

class deduceArrayFromSum(object):
    def __init__(self, data_sum, data_len):
        self.expected_sum = data_sum
        self.data_len = data_len
        self.interval = ()
        self.dictionary = {}
        self.dictionary_interval = ()
        
        self.expected_xor = None
        self.expected_crc32 = None
        self.expected_md5 = None
        
        self.response = None
        self.counters = {'hits_sum': 0, 'hits_xor': 0, 'hits_crc32': 0, 'hits_md5': 0}

    def expect_xor(self, val):
        self.expected_xor = val
    
    def expect_crc32(self, val):
        self.expected_crc32 = val
        
    def expect_md5(self, val):
        self.expected_md5 = val
    
    def hint_interval(self, interval_start, interval_end):
        intv = (interval_start, interval_end)
        self.interval = (max(intv), min(intv))
        
    def hint_dictionary(self, dictionary):
        d = list(set(dictionary)) # keep only unique values
        d.sort(reverse=True)
        self.dictionary_interval = (min(d), max(d))
        self.dictionary = d

    def runFromStartupData(self, startup_data):
        start_data_lst = map(ord, list(startup_data))

        data = bytearray("\x00" * (self.data_len))
        data = startup_data + data[len(startup_data):]

        expected_sum = self.expected_sum - sum(start_data_lst)
        lxor = 0x00
        for i in start_data_lst:
            lxor = lxor^i

        lastval = start_data_lst[-1]

        #print("sdata: '%s'(s:%d), exps: %d, s.exps: %d" % (startup_data, sum(map(ord, list(startup_data))), expected_sum, self.expected_sum))

        if len(self.dictionary):
            helpers.dlog("Using dictionary of %d elements, startup: %s[%d]\n" % (len(self.dictionary), startup_data, len(startup_data)))
            self._runOnDictionary(data, expected_sum, len(startup_data), lxor, self.dictionary.index(lastval))
        elif len(self.interval):
            helpers.dlog("Using interval of %d elements, startup: %s[%d]\n" % (self.interval[0] - self.interval[1], startup_data, len(startup_data)))
            self._runOnInterval(data, expected_sum, len(startup_data), lxor, lastval)
        else:
            helpers.dlog("Using brute-force, startup: %s[%d]\n" %(startup_data, len(startup_data)))
            self.interval = (0xff, 0x00)
            self._runOnInterval(data, expected_sum, len(startup_data), lxor, lastval)
            self.interval = ()
        return self.response
    
    def run(self):
        data = bytearray("\x00" * (self.data_len))
        
        if len(self.dictionary):
            helpers.dlog("Using dictionary of %d elements\n" % (len(self.dictionary)))
            self._runOnDictionary(data, self.expected_sum, 0, 0x00, 0)
        elif len(self.interval):
            helpers.dlog("Using interval of %d elements\n" % (self.interval[0] - self.interval[1]))
            self._runOnInterval(data, self.expected_sum, 0, 0x00, self.interval[0])
        else:
            helpers.dlog("Using brute-force\n")
            self.interval = (0xff, 0x00)
            self._runOnInterval(data, self.expected_sum, 0, 0x00, self.interval[0])
            self.interval = ()
        return self.response
    
    
    def _runOnDictionary(self, data, csum, d, lxor, dictionaryStartOffset):
        if d==self.data_len and csum:
            return 0
            
        if d<self.data_len and csum:
            offset = dictionaryStartOffset
            internalOffset=0

            for i in self.dictionary[offset+internalOffset:]:
                nsum = csum-i
                data[d] = i
                cxor = lxor ^ i
                
                if nsum==0: # hit target sum
                    self.counters['hits_sum']+=1
                    #helpers.dlog("Found sum match on %s\n" % (data))
                    
                    if xor==cxor:
                        self.counters['hits_xor']+=1
                        #helpers.dlog("Found xor match\n")
                        if self.checkSuccess(data):
                            return d    # exit from all current function calls
                    else:
                        if self.counters['hits_sum']%1000==0:
                            self.progress(data) # optimize this out
                        return 0
                        
                elif nsum<0:
                    return 0
                elif nsum<self.dictionary_interval[0]:
                    return 0
                else:
                    ret = self._runOnDictionary(data, nsum, d+1, cxor, offset+internalOffset)
                    if ret>0:
                        return ret-1
                        
                internalOffset+=1
        return 0
    
    def _runOnInterval(self, data, csum, d, lxor, intervalStart):
        if d==self.data_len and csum:
            return 1
            
        if d<self.data_len and csum:
            i = min(intervalStart, csum)
            
            while i>=self.interval[1]:
                nsum = csum-i # new sum, hopefully as close to 0 as possible
                data[d] = i
                cxor = lxor ^ i
                
                if nsum==0: # hit target sum
                    self.counters['hits_sum']+=1
                    #helpers.dlog("Found sum match\n")
                    
                    if xor==cxor:
                        self.counters['hits_xor']+=1
                        #helpers.dlog("Found xor match\n")
                        if self.checkSuccess(data):
                            return d    # exit from all current function calls
                    else:
                        if self.counters['hits_sum']%10000==0:
                            self.progress(data) # optimize this out
                        return 0
                elif nsum<0:
                    return 0
                elif nsum<self.interval[1]:
                    return 0
                else:
                    ret = self._runOnInterval(data, nsum, d+1, cxor, i)
                    if ret>0:
                        return ret-1
                i=i-1
        return 0
        
    def createStartupIntervals(self, d_max):
        if len(self.dictionary):
            l = self._createStartupIntervalsOnDictionary(0, d_max, bytearray("\x00" * d_max), self.dictionary, [])
        elif len(self.interval):
            l = self._createStartupIntervalsOnInterval(0, d_max, bytearray("\x00" * d_max), [])
        else:
            self.interval = (0xff, 0x00)
            l = self._createStartupIntervalsOnInterval(0, d_max, bytearray("\x00" * d_max), [])
            self.interval = ()

        return l

    def _createStartupIntervalsOnDictionary(self, d, d_max, data, dictionary, lst):
        if d==d_max:
            lst.append(data[:])  # append a clone of the data
            return lst

        idx = 0
        for i in dictionary:
            data[d] = i
            lst = self._createStartupIntervalsOnDictionary(d+1, d_max, data, dictionary[idx:],lst)
            idx+=1

        return lst


    def _createStartupIntervalsOnInterval(self, d, d_max, data, lst):
        if d==d_max:
            lst.append(data[:])  # append a clone of the data
            return lst

        i = self.interval[0]
        while i>=self.interval[1]:
            data[d] = i
            lst = self._createStartupIntervalsOnInterval(d+1, d_max, data, lst)
            i=i-1

        return lst

    def progress(self, data):
        helpers.dlogt(0.2, "%s, %s/%s/%d/%d\r" % (re.sub("[^a-zA-Z0-9]", "_", data), 
            (str(self.counters['hits_sum']) if self.counters['hits_sum']<10000 else str(self.counters['hits_sum']/1000)+"k"),
            (str(self.counters['hits_xor']) if self.counters['hits_xor']<10000 else str(self.counters['hits_xor']/1000)+"k"),
            self.counters['hits_crc32'],
            self.counters['hits_md5'])
        )
    
    def checkSuccess(self, data):
        datacrc = zlib.crc32(str(data)) & 0xffffffff
        if datacrc==self.expected_crc32:
            self.counters['hits_crc32']+=1
            datamd5 = hashlib.md5(data).hexdigest()
            if datamd5==self.expected_md5:
                self.counters['hits_md5']+=1
                helpers.dlog("\n\nFound md5 match\n")
                helpers.dlog("Data: '%s'[%d]\n" % (data, len(data)))
                self.response = data
                return True
                
        return False


if __name__ == '__main__':
    asum = int(sys.argv[1])
    alen = int(sys.argv[2])
    md5 = str(sys.argv[3])
    crc32 = int(str(sys.argv[4]), 16) & 0xffffffff
    xor = int(str(sys.argv[6]), 16) & 0xff


    helpers.dlog("Started deduce array from sum\n")
    d = deduceArrayFromSum(asum, alen)
    #d.hint_interval(ord('0'), ord('9'))
    #d.hint_dictionary(map(ord, ['6', '5', '4', '3', '2', '1', 'e', 'q', 'w', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o']))
    
    #d.hint_interval(ord('a'), ord('z'))
    #d.hint_interval(ord('0'), ord('9'))
    d.hint_dictionary(map(ord, list("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ")))
    #d.hint_dictionary(map(ord, list("abcdefghijklmnopqrstuvwxyz")))
    #d.hint_dictionary(map(ord, list("rnmea")))
    #d.hint_dictionary(map(ord, list("0123456789ab")))

    #intv = d.createStartupIntervals(2)
    #print "\n".join(map(str, intv))

    d.expect_xor(xor)
    d.expect_crc32(crc32)
    d.expect_md5(md5)
    #result = d.run()
    result = d.runFromStartupData("rrn")
    if not result:
        print("")
        print(" -------------------------------------- ")
        print("Cannot decode input data")
        print("")
        print("")
    else:
        print("")
        print("Input data decoded into '%s'" % result)
    print(d.counters)
    
    
"""
#interval = [0xff, 0x00]
#deduceArrayFromSum(arr, asum, 0, alen, interval[0], interval[1], xor, 0x00)

#interval = [ord('z'), ord('a')]
#deduceArrayFromSum(arr, asum, 0, alen, interval[0], interval[1], xor, 0x00)

if __name__ == '__main__':
    interval = [ord('z'), ord('a')]
    #deduceArrayFromSum(arr, asum, 0, alen, interval[0], interval[1], xor, 0x00)

    q = Queue()

    p1 = Process(target=deduceArrayFromSum, args=(arr, asum, 0, alen, interval[0], interval[1], xor, 0x00))
    p1.start()
    p1.join()

    if not q.empty():
        helpers.dlog("Queue: "+q.get()+"\n")
    else:
        helpers.dlog("Queue empty\n")


    helpers.dlog("Cannot decode input data\n")
"""
