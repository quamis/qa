import sys
import helpers
import hashlib
import re
import copy

def deduceArrayFromSum(arr, asum, offset, maxOffset, li, mi):
    if offset<=maxOffset:
        if asum>0:
            i = min(li, asum)
            while i>=mi:
                if asum>=i and offset<maxOffset:
                    arr[offset] = i
                    deduceArrayFromSum(arr, asum-i, offset+1, maxOffset, i, mi)
                i=i-1
        elif asum==0:
            cb(arr)

def cb(iarr):
    global md5
    data = helpers.reimplode(iarr)
    
    datamd5 = hashlib.md5(data).hexdigest()
    
    #helpers.dlog("%s[%d] %s\n" % (re.sub("[^a-zA-Z0-9]", "_", helpers.reimplodehex(iarr)), len(data), datamd5))
    
    if datamd5==md5:
        helpers.dlog("Found data\n")
        helpers.dlog("Data: '%s'[%d]\n" % (data, len(data)))
        sys.exit()
        

asum = int(sys.argv[1]);
alen = int(sys.argv[2]);
md5 = str(sys.argv[3]);

arr = [0] * (alen)
helpers.dlog("Started deduce array from sum\n")
deduceArrayFromSum(copy.copy(arr), asum, 0, alen, 0xff, 0x00)
helpers.dlog("Cannot decode input data\n")

