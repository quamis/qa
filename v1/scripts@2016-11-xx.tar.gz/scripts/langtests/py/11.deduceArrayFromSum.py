# 120s for 6ch
import sys
import helpers
import hashlib
import re
import copy

def deduceArrayFromSum(arr, asum, offset, maxOffset, li, mi):
    if offset==maxOffset and asum:
        return 1
                
    if offset<maxOffset and asum:
        if asum>0:
            i = min(li, asum)
            while i>=mi:
                ns = asum-i
                arr[offset] = i
                if ns==0:
                    cb(arr)
                else:
                    ret = deduceArrayFromSum(arr, ns, offset+1, maxOffset, i, mi)
                    if ret>0:
                        return ret-1
                i=i-1
    return 0

def cb(data):
    global md5
    
    datamd5 = hashlib.md5(data).hexdigest()
    
    #helpers.dlog("%s[%d] %s\r" % (re.sub("[^a-zA-Z0-9]", "_", data), len(data), datamd5))
    
    if datamd5==md5:
        helpers.dlog("Found data\n")
        helpers.dlog("Data: '%s'[%d]\n" % (data, len(data)))
        sys.exit()
        

asum = int(sys.argv[1]);
alen = int(sys.argv[2]);
md5 = str(sys.argv[3]);
crc32 = str(sys.argv[4]);
adler32 = str(sys.argv[5]);

sarr = "\x00" * (alen)
arr = bytearray(sarr)
helpers.dlog("Started deduce array from sum\n")
deduceArrayFromSum(arr, asum, 0, alen, 0xff, 0x00)
helpers.dlog("Cannot decode input data\n")

